using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    [SerializeField] private float timeToCompleteQuestion = 30f;
    [SerializeField] private float timeToShowCorrectAnswer = 5f;

    public float timerValue;
    public bool isAnsweringQuestion = true;
    public float fillFraction;
    public bool loadNextQuestion;

    [SerializeField] private Image timerImage;

    void Update()
    {
        UpdateTime();

        if (timerImage != null)
        {
            timerImage.fillAmount = fillFraction;
        }

        if (loadNextQuestion)
        {
            // O Questionnaire vai tratar de chamar a pr�xima pergunta e limpar este bool
            loadNextQuestion = false;
        }
    }

    public void UpdateTime()
    {
        if (isAnsweringQuestion)
        {
            timerValue -= Time.deltaTime;

            if (timerValue <= 0)
            {
                isAnsweringQuestion = false;
                timerValue = timeToShowCorrectAnswer;
            }
            else
            {
                fillFraction = timerValue / timeToCompleteQuestion;
            }
        }
        else
        {
            timerValue -= Time.deltaTime;

            if (timerValue <= 0)
            {
                isAnsweringQuestion = true;
                timerValue = timeToCompleteQuestion;
                loadNextQuestion = true;
            }
            else
            {
                fillFraction = timerValue / timeToShowCorrectAnswer;
            }
        }
    }

    public void CancelTimer()
    {
        timerValue = 0;
    }
}