using UnityEngine;

[CreateAssetMenu(fileName = "New Question", menuName = "Quiz/Question")]
public class QuestionSO : ScriptableObject
{
    [TextArea(2, 5)]
    [SerializeField]
    private string question;

    [SerializeField]
    private string[] limite = new string[4];

    [SerializeField]
    private int correta;
    public string GetQuestion()
    {
        return question;
    }

    public string[] GetAnswers()
    {
        return limite;
    }
    public int GetCorrectAnswerIndex()
    {
        return correta;
    }
    public string GetAnswer(int index)
    {
        return limite[index];
    }
}