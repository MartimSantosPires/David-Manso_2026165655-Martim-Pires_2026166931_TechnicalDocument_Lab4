using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class Questionnaire : MonoBehaviour
{
    [SerializeField] private QuestionSO questionSO;
    [SerializeField] private TextMeshProUGUI questionText;
    [SerializeField] private GameObject[] answerButtons;

    private int correctAnswerIndex;
    private Timer timer;
    private bool hasAnsweredEarly;

    void Start()
    {
        timer = FindFirstObjectByType<Timer>();
        GetNextQuestion();
    }

    void Update()
    {
        if (timer.loadNextQuestion)
        {
            GetNextQuestion();
        }
        else if (hasAnsweredEarly && !timer.isAnsweringQuestion)
        {
            DisplayAnswer(correctAnswerIndex);
            hasAnsweredEarly = false;
        }
    }

    public void GetNextQuestion()
    {
        SetButtonState(true);
        DisplayQuestion();
    }

    public void DisplayQuestion()
    {
        questionText.text = questionSO.GetQuestion();
        correctAnswerIndex = questionSO.GetCorrectAnswerIndex();

        for (int i = 0; i < answerButtons.Length; i++)
        {
            TextMeshProUGUI buttonText = answerButtons[i].GetComponentInChildren<TextMeshProUGUI>();
            if (buttonText != null)
            {
                buttonText.text = questionSO.GetAnswer(i);
            }
        }
    }

    public void OnAnswerSelected(int index)
    {
        hasAnsweredEarly = true;
        SetButtonState(false);
        timer.CancelTimer();

        if (index == correctAnswerIndex)
        {
            questionText.text = "Correto!";
        }
        else
        {
            string correctAnswer = questionSO.GetAnswer(correctAnswerIndex);
            questionText.text = "Desculpa, mas a resposta correta �: " + correctAnswer;
        }
    }

    public void DisplayAnswer(int index)
    {
        if (index == correctAnswerIndex)
        {
            questionText.text = "Correto!";
        }
        else
        {
            string correctAnswer = questionSO.GetAnswer(correctAnswerIndex);
            questionText.text = "Desculpa, mas a resposta correta �: " + correctAnswer;
        }
    }

    public void SetButtonState(bool state)
    {
        for (int i = 0; i < answerButtons.Length; i++)
        {
            Button btn = answerButtons[i].GetComponent<Button>();
            if (btn != null)
            {
                btn.interactable = state;
            }
        }
    }
}